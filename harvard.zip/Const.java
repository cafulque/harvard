//
package cafu.prode;

public class Const {

    public static final int PUNTOS_APUESTA = 0;         // punto/s por haber apostado (gane o pierda)
    public static final int PUNTOS_GANADOS = 1;         // punto/s ganado/s por acertar predicción
    public static final int BONUS = 1;                  // bonus por acertar predicciones de una fase

    public static final boolean HEADER = true;          // table with header
    public static final boolean NO_HEADER = false;      // table without header

    // constantes de entorno para SQL Server
    public static final String DB = "JavaTP";
    public static final String PORT = "1433";
    public static final String USER = "userSQL";
    public static final String PASS = "passSQL";
    public static final String NAME = ";databaseName=";
    public static final String HOST = "DESKTOP-HOPKK28:";
    public static final String JDBC = "jdbc:";
    public static final String ENCRY = ";encrypt=true";
    public static final String TRUST = ";trustServerCertificate=true";
    public static final String URL = JDBC + "sqlserver://" + HOST + PORT + NAME + DB + ENCRY + TRUST;

/*
    // constantes de entorno para MySQL
    public static final String DB = "/JavaTP";
    public static final String PORT = "3306";
    public static final String USER = "userSQL";
    public static final String PASSA = "passSQL";
    public static final String HOST = "localhost:";
    public static final String JDBC = "jdbc:";
    public static final String URL = jdbc + "mysql://" + host + port + db;
    public static final String DRV = "com.mysql.cj.jdbc.Driver;
*/

}


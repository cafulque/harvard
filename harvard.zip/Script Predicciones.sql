-- SQL SCRIPT

-- script Predicciones.sql
use JavaTP;

-- drop table Predicciones
if object_id ('dbo.Predicciones', 'U') is not null
	drop table dbo.Predicciones;
go

-- create table Predicciones
create table Predicciones (
	id int not null identity(1, 1) primary key,
	jugador varchar(10) not null,
	equipo1 varchar(15) not null,
	local char(1) not null,
	empate char(1) not null,
	visitante char(1) not null,
	equipo2 varchar(15) not null,
	partido int not null
) engine=InnoDB;

-- insert rows to Predicciones
set identity_insert Predicciones on;

insert into Predicciones (id, jugador, equipo1, local, empate, visitante, equipo2, partido) values
(  '1', 'Mariana', 'Argentina',      'X',  '',  '', 'Arabia Saudita',  '1'),
(  '2', 'Mariana', 'Polonia',         '', 'X',  '', 'Mexico',          '2'),
(  '3', 'Mariana', 'Argentina',      'X',  '',  '', 'Mexico',          '3'),
(  '4', 'Mariana', 'Arabia Saudita',  '',  '', 'X', 'Polonia',         '4'),
(  '5', 'Mariana', 'Paises Bajos',   'X',  '',  '', 'Estados Unidos',  '5'),
(  '6', 'Mariana', 'Argentina',      'X',  '',  '', 'Australia',       '6'),
(  '7', 'Mariana', 'Francia',        'X',  '',  '', 'Polonia',         '7'),
(  '8', 'Mariana', 'Inglaterra',     'X',  '',  '', 'Senegal',         '8'),
(  '9', 'Mariana', 'Japon',           '',  '', 'X', 'Croacia',         '9'),
( '10', 'Mariana', 'Brasil',         'X',  '',  '', 'Corea del Sur',  '10'),
( '11', 'Mariana', 'Marruecos',       '',  '', 'X', 'España',         '11'),
( '12', 'Mariana', 'Portugal',       'X',  '',  '', 'Suiza',          '12'),
( '13', 'Mariana', 'Croacia',         '',  '', 'X', 'Brasil',         '13'),
( '14', 'Mariana', 'Paises Bajos',    '',  '', 'X', 'Argentina',      '14'),
( '15', 'Mariana', 'Marruecos',       '',  '', 'X', 'Portugal',       '15'),
( '16', 'Mariana', 'Inglaterra',     'X',  '',  '', 'Francia',        '16'),
( '17', 'Mariana', 'Argentina',      'X',  '',  '', 'Croacia',        '17'),
( '18', 'Mariana', 'Francia',        'X',  '',  '', 'Marruecos',      '18'),
( '19', 'Mariana', 'Croacia',        'X',  '',  '', 'Marruecos',      '19'),
( '20', 'Mariana', 'Argentina',      'X',  '',  '', 'Francia',        '20'),
( '21',   'Pedro', 'Argentina',      'X',  '',  '', 'Arabia Saudita',  '1'),
( '22',   'Pedro', 'Polonia',         '',  '', 'X', 'Mexico',          '2'),
( '23',   'Pedro', 'Argentina',      'X',  '',  '', 'Mexico',          '3'),
( '24',   'Pedro', 'Arabia Saudita',  '', 'X',  '', 'Polonia',         '4'),
( '25',   'Pedro', 'Paises Bajos',   'X',  '',  '', 'Estados Unidos',  '5'),
( '26',   'Pedro', 'Argentina',      'X',  '',  '', 'Australia',       '6'),
( '27',   'Pedro', 'Francia',        'X',  '',  '', 'Polonia',         '7'),
( '28',   'Pedro', 'Inglaterra',     'X',  '',  '', 'Senegal',         '8'),
( '29',   'Pedro', 'Japon',           '',  '', 'X', 'Croacia',         '9'),
( '30',   'Pedro', 'Brasil',         'X',  '',  '', 'Corea del Sur',  '10'),
( '31',   'Pedro', 'Marruecos',       '',  '', 'X', 'España',         '11'),
( '32',   'Pedro', 'Portugal',       'X',  '',  '', 'Suiza',          '12'),
( '33',   'Pedro', 'Croacia',         '',  '', 'X', 'Brasil',         '13'),
( '34',   'Pedro', 'Paises Bajos',    '',  '', 'X', 'Argentina',      '14'),
( '35',   'Pedro', 'Marruecos',       '',  '', 'X', 'Portugal',       '15'),
( '36',   'Pedro', 'Inglaterra',     'X',  '',  '', 'Francia',        '16'),
( '37',   'Pedro', 'Argentina',      'X',  '',  '', 'Croacia',        '17'),
( '38',   'Pedro', 'Francia',        'X',  '',  '', 'Marruecos',      '18'),
( '39',   'Pedro', 'Croacia',        'X',  '',  '', 'Marruecos',      '19'),
( '40',   'Pedro', 'Argentina',      'X',  '',  '', 'Francia',        '20'),
( '41',   'Jorge', 'Argentina',       '',  '', 'X', 'Arabia Saudita',  '1'),
( '42',   'Jorge', 'Polonia',         '', 'X',  '', 'Mexico',          '2'),
( '43',   'Jorge', 'Argentina',      'X',  '',  '', 'Mexico',          '3'),
( '44',   'Jorge', 'Arabia Saudita',  '',  '', 'X', 'Polonia',         '4'),
( '45',   'Jorge', 'Paises Bajos',   'X',  '',  '', 'Estados Unidos',  '5'),
( '46',   'Jorge', 'Argentina',      'X',  '',  '', 'Australia',       '6'),
( '47',   'Jorge', 'Francia',        'X',  '',  '', 'Polonia',         '7'),
( '48',   'Jorge', 'Inglaterra',     'X',  '',  '', 'Senegal',         '8'),
( '49',   'Jorge', 'Japon',           '',  '', 'X', 'Croacia',         '9'),
( '50',   'Jorge', 'Brasil',         'X',  '',  '', 'Corea del Sur',  '10'),
( '51',   'Jorge', 'Marruecos',       '',  '', 'X', 'España',         '11'),
( '52',   'Jorge', 'Portugal',       'X',  '',  '', 'Suiza',          '12'),
( '53',   'Jorge', 'Croacia',         '',  '', 'X', 'Brasil',         '13'),
( '54',   'Jorge', 'Paises Bajos',    '',  '', 'X', 'Argentina',      '14'),
( '55',   'Jorge', 'Marruecos',       '',  '', 'X', 'Portugal',       '15'),
( '56',   'Jorge', 'Inglaterra',     'X',  '',  '', 'Francia',        '16'),
( '57',   'Jorge', 'Argentina',      'X',  '',  '', 'Croacia',        '17'),
( '58',   'Jorge', 'Francia',        'X',  '',  '', 'Marruecos',      '18'),
( '59',   'Jorge', 'Croacia',        'X',  '',  '', 'Marruecos',      '19'),
( '60',   'Jorge', 'Argentina',      'X',  '',  '', 'Francia',        '20'),
( '61', 'Leticia', 'Argentina',       '',  '', 'X', 'Arabia Saudita',  '1'),
( '62', 'Leticia', 'Polonia',         '', 'X',  '', 'Mexico',          '2'),
( '63', 'Leticia', 'Argentina',       '',  '', 'X', 'Mexico',          '3'),
( '64', 'Leticia', 'Arabia Saudita', 'X',  '',  '', 'Polonia',         '4'),
( '65', 'Leticia', 'Paises Bajos',   'X',  '',  '', 'Estados Unidos',  '5'),
( '66', 'Leticia', 'Argentina',      'X',  '',  '', 'Australia',       '6'),
( '67', 'Leticia', 'Francia',        'X',  '',  '', 'Polonia',         '7'),
( '68', 'Leticia', 'Inglaterra',     'X',  '',  '', 'Senegal',         '8'),
( '69', 'Leticia', 'Japon',           '',  '', 'X', 'Croacia',         '9'),
( '70', 'Leticia', 'Brasil',         'X',  '',  '', 'Corea del Sur',  '10'),
( '71', 'Leticia', 'Marruecos',       '',  '', 'X', 'España',         '11'),
( '72', 'Leticia', 'Portugal',       'X',  '',  '', 'Suiza',          '12'),
( '73', 'Leticia', 'Croacia',         '',  '', 'X', 'Brasil',         '13'),
( '74', 'Leticia', 'Paises Bajos',    '',  '', 'X', 'Argentina',      '14'),
( '75', 'Leticia', 'Marruecos',       '',  '', 'X', 'Portugal',       '15'),
( '76', 'Leticia', 'Inglaterra',     'X',  '',  '', 'Francia',        '16'),
( '77', 'Leticia', 'Argentina',      'X',  '',  '', 'Croacia',        '17'),
( '78', 'Leticia', 'Francia',        'X',  '',  '', 'Marruecos',      '18'),
( '79', 'Leticia', 'Croacia',        'X',  '',  '', 'Marruecos',      '19'),
( '80', 'Leticia', 'Argentina',      'X',  '',  '', 'Francia',        '20');

set identity_insert Predicciones off;

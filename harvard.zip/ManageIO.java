//
package cafu.prode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;


public class ManageIO {


    // variables
    private static int qtyColumns;

    private static Statement stmt = null;
    private static Connection conx = null;
    private static String select = null;

    private static ResultSet ress = null;
    private static ResultSetMetaData metaData;
    private static List <String> rowsTable = new ArrayList<>();
    private static final StringBuilder row = new StringBuilder();

    // constructor
    public ManageIO() {
        super();
    }


    // read rows from a "csv" file
    public static List <String> readRowsCSV(String archivo) {

        try {
            rowsTable.clear();                                              // clear rows
            rowsTable = Files.readAllLines(Paths.get(archivo));
        } catch (IOException ex) {
            System.out.println("Imposible leer el archivo " + archivo);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.exit(100);
        }

        return rowsTable;
    }


    // SQL Server connection
    public static void ConnectSQL() {

        try {                                                               // open connection
            conx = DriverManager.getConnection(Const.URL, Const.USER, Const.PASS);
            System.out.println("Conexión exitosa a " + Const.DB + "!");
        } catch (SQLException ex) {
            System.out.println("Imposible acceder a la base de datos \"" + Const.DB + "\"");
            System.out.println("URL " + Const.URL);
            System.out.println("Por favor, comuníquese con el personal de sistemas!");
            System.out.println("Exception: " + ex + "\n\n");
            System.exit(100);
        }

    }


    // SQL Server disconnection
    public static void DisConnectSQL() {

        try {                                                               // close connection
            conx.close();
            System.out.println("Desconexión exitosa de " + Const.DB + "!");
        } catch (SQLException ex) {
            System.out.println("Imposible cerrar la base de datos \"" + Const.DB + "\"");
            System.out.println("URL " + Const.URL);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.out.println("Exception: " + ex + "\n\n");
            System.exit(200);
        } finally {
            try {
                if (ress != null) ress.close();                             // release resultset
                if (stmt != null) stmt.close();                             // release statement
                if (conx != null) conx.close();                             // release connection
            } catch (SQLException ex) {
                System.out.println("Imposible liberar recursos de la base de datos \"" + Const.DB + "\"");
                System.out.println("URL " + Const.URL);
                System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
                System.out.println("Exception: " + ex + "\n\n");
                System.exit(300);
            }
        }

    }


    // read rows from SQL table
    public static List <String> readRowsSQL(String table) throws SQLException {

        select = "select * from " + table + ";";                            // select/table

        try {

            conx = DriverManager.getConnection(Const.URL, Const.USER, Const.PASS);
            stmt = conx.createStatement();                                  // SQL instance
            ress = stmt.executeQuery(select);                           // exec SQL sentence

            metaData = ress.getMetaData();                                  // meta info
            qtyColumns = metaData.getColumnCount();                         // qty columns
            rowsTable.clear();                                              // clear rows

            while (ress.next()) {                                           // rows iterator
                row.setLength(0);                                   // clear rows
                for (int i = 1; i <= qtyColumns; i++) {                     // columns iterator
                    row.append(ress.getString(i)).append(";");
                }
                rowsTable.add(row.toString());							// add row to List<String>

            }

            if (ress != null) ress.close();                                 // release resultset

        } catch (SQLException ex) {
            System.out.println("Imposible instanciar o leer la base de datos \"" + Const.DB + "\"");
            System.out.println("URL " + Const.URL);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.out.println("Exception: " + ex + "\n\n");
            System.exit(200);
        } finally {
            try {
                if (ress != null) ress.close();                             // release resultset
                if (stmt != null) stmt.close();                             // release statement
                if (conx != null) conx.close();                             // release connection
            } catch (SQLException ex) {
                System.out.println("Imposible liberar recursos de la base de datos \"" + Const.DB + "\"");
                System.out.println("URL " + Const.URL);
                System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
                System.out.println("Exception: " + ex + "\n\n");
                System.exit(300);
            }
        }

        return rowsTable;

    }


    // exec any SQL sentence from any db
    public static List <String> sentenceSQL(String url, String user, String pass, String select) throws SQLException {

        try {

            conx = DriverManager.getConnection(url, user, pass);    // db connection
            stmt = conx.createStatement();                                  // instance to SQL
            ress = stmt.executeQuery(select);                           // exec SQL sentence

            metaData = ress.getMetaData();                                  // meta info
            qtyColumns = metaData.getColumnCount();                         // qty columns
            rowsTable.clear();                                              // clear rows
// rows aggregation check
            while (ress.next()) {                                           // rows iterator
                row.setLength(0);                                   // clear rows
                for (int i = 1; i <= qtyColumns; i++) {                     // columns iterator
                    row.append(ress.getString(i)).append(";");
                }
                rowsTable.add(row.toString());							// add row to List<String>
            }

            if (ress != null) ress.close();                                 // release resultset

        } catch (SQLException ex) {
            System.out.println("Imposible instanciar o leer la base de datos ");
            System.out.println("URL " + url);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.out.println("Exception: " + ex + "\n\n");
            System.exit(200);
        } finally {
            try {
                if (ress != null) ress.close();                             // release resultset
                if (stmt != null) stmt.close();                             // release statement
                if (conx != null) conx.close();                             // release connection
            } catch (SQLException ex) {
                System.out.println("Imposible liberar recursos de la base de datos \"" + Const.DB + "\"");
                System.out.println("URL " + Const.URL);
                System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
                System.out.println("Exception: " + ex + "\n\n");
                System.exit(300);
            }
        }

        return rowsTable;

    }

}



package cafu.prode;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Totales {
    
    // declaraciones
    public static int count, puntos, partido, bonus;
    public static boolean header;
    public static String jugador, fase;
    public static String ganador, clave, valor;
    public static String lineas, titulo;
    public static String campos[];

    // constructor
    public Totales() {
        super();
    }

    // método para mostrar el archivo "resultados.csv"
    public static void showResultados(List <String> lineasResultados) {

        header = true;

        System.out.println();
        lineas = "------------------------------------------------------------------------";
        titulo = "|                           <<< RESULTS >>>                           |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String line : lineasResultados) {

            campos = line.split(";");
            System.out.println(String.format("| %4s | %-15s | %7s | %7s | %-15s | %7s |",
                               campos[0], campos[1], campos[2], campos[3], campos[4], campos[5]));

            if (header) {
                System.out.println("|" + lineas + "|");
                header = false;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar el archivo "predicciones.csv"
    public static void showPredicciones(List <String> lineasPredicciones) {

        header = true;

        System.out.println();
        lineas = "--------------------------------------------------------------------------------------";
        titulo = "|                                 <<< PREDICTIONS >>>                                 |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String line : lineasPredicciones) {

            campos = line.split(";");

            System.out.println(String.format("| %-10s | %-15s |  %-6s | %-6s | %-6s | %-15s | %7s |",
                  campos[0], campos[1], campos[2], campos[3], campos[4], campos[5], campos[6]));

            if (header) {
                System.out.println("|" + lineas + "|");
                header = false;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar el detalle de puntos obtenidos por cada jugador y fases
    public static void showJugadorFasePuntos(TreeMap <String, String> jugadorFasePuntos) {

        count = 0;
        puntos = 0;
        header = true;
        bonus = Const.PUNTOS_APUESTA;
        String jugadorAnterior = "";

        System.out.println();
        lineas = "------------------------------------";
        titulo = "| <<< PLAYER AND PHASES POINTS >>> |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (Map.Entry<String, String> line : jugadorFasePuntos.entrySet()) {

            clave = line.getKey();                                      // jugador;fase;partidos, partidos --> acum
            campos = clave.split(";");
            jugador = campos[0];
            fase = campos[1];
            partido = Integer.parseInt(campos[2]);

            valor = line.getValue();                                    // acumulador de puntos
            campos = valor.split(";");
            
            if (header) {
                System.out.println("| Jugador    | Fase | Puntos | Bonus |");
                System.out.println("|" + lineas + "|");
                jugadorAnterior = jugador;
                header = false;
            }

            if (!jugador.equals(jugadorAnterior)) {
                System.out.println("+" + lineas + "+");
                jugadorAnterior = jugador;
            }

            System.out.println(String.format("| %-10s | %4s |  %5s | %5s |",
                             jugador, fase, campos[0], campos[1]));

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar la cantidad de puntos obtenidos por jugador
    public static void showTotalesJugador(List <String> lineasResultados, List <String> lineasPredicciones,
                       Map <String, Integer> puntosJugador, TreeMap <String, String> jugadorFasePuntos) {

        count = 0;
        puntos = 0;
        header = true;

        System.out.println();
        lineas = "---------------------";
        titulo = "| < PLAYERS TOTALS > |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String player : puntosJugador.keySet()) {

            if (header) {
                System.out.println("| Jugador    | Puntos |");
                System.out.println("|" + lineas + "|");
                header = false;
            }

            puntos = puntosJugador.get(player);

            System.out.println(String.format("| %-10s | %6d |", player, puntos));

            if (puntosJugador.get(player) > count) {
                count = puntosJugador.get(player);
                ganador = player;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar el nombre del jugador que ganó el prode
    public static void showGanador(List <String> lineasResultados, List <String> lineasPredicciones,
                       Map <String, Integer> puntosJugador, TreeMap <String, String> jugadorFasePuntos) {

        System.out.println();
        lineas = "---------------------";
        titulo = "|   <<< WINNER >>>   |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");
        System.out.println(String.format("|       %-10s    |", ganador));
        System.out.println("+" + lineas + "+");
        System.out.println("\n");

    }

}


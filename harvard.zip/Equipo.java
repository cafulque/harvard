//
package cafu.prode;

public class Equipo {

    // declaraciones
    private String nombre;
    private String descripcion;

    // constructor
    public Equipo(String nombre) {
        super();
        this.nombre = nombre;
    }

    // getters & setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

}


//
package cafu.prode;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class Show {


    // variables
    public static int count, puntos, partido, bonus;
    public static boolean header;
    public static String jugador, fase;
    public static String ganador, clave, valor;
    public static String lineas, titulo;
    public static String campos[];


    // constructor
    public Show() {
        super();
    }


    // muestra contenido "resultados"
    public static void Resultados(List <String> filasResultados) {

        header = true;

        System.out.println();
        lineas = "------------------------------------------------------------------------";
        titulo = "|                           <<< RESULTS >>>                           |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String fila : filasResultados) {

            if (header) {
                System.out.println("| Fase | Equipo 1        | Goles 1 | Goles 2 | Equipo 2        | Partido |");
                System.out.println("|" + lineas + "|");
                header = false;
            }

            campos = fila.split(";");
            System.out.println(String.format("| %4s | %-15s | %7s | %7s | %-15s | %7s |",
                               campos[1], campos[2], campos[3], campos[4], campos[5], campos[6]));

        }

        System.out.println("+" + lineas + "+");

    }


    // muestra contenido "predicciones"
    public static void Predicciones(List <String> filasPredicciones) {

        header = true;

        System.out.println();
        lineas = "------------------------------------------------------------------------------------------";
        titulo = "|                                   <<< PREDICTIONS >>>                                   |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String fila : filasPredicciones) {

            if (header) {
                System.out.println("| Jugador         | Equipo 1        | Local  | Empate | Visita | Equipo 2        | Partido |");
                System.out.println("|" + lineas + "|");
                header = false;
            }

            campos = fila.split(";");

            System.out.println(String.format("| %-15s | %-15s | %-6s | %-6s | %-6s | %-15s | %7s |",
                  campos[1], campos[2], campos[3], campos[4], campos[5], campos[6], campos[7]));

        }

        System.out.println("+" + lineas + "+");

    }


    // muestra el detalle de puntos obtenidos por cada jugador y fases
    public static void JugadorFasePuntos(TreeMap <String, String> jugadorFasePuntos) {

        count = 0;
        puntos = 0;
        header = true;
        bonus = Const.PUNTOS_APUESTA;
        String jugadorAnterior = "";

        System.out.println();
        lineas = "-----------------------------------------";
        titulo = "|   <<< PLAYER AND PHASES POINTS >>>    |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (Map.Entry<String, String> fila : jugadorFasePuntos.entrySet()) {

            clave = fila.getKey();                                      // jugador;fase;partidos, partidos --> acum
            campos = clave.split(";");
            jugador = campos[0];
            fase = campos[1];
            partido = Integer.parseInt(campos[2]);

            valor = fila.getValue();                                    // acumulador de puntos
            campos = valor.split(";");

            if (header) {
                System.out.println("| Jugador         | Fase | Puntos | Bonus |");
                System.out.println("|" + lineas + "|");
                jugadorAnterior = jugador;
                header = false;
            }

            if (!jugador.equals(jugadorAnterior)) {
                System.out.println("+" + lineas + "+");
                jugadorAnterior = jugador;
            }

            System.out.println(String.format("| %-15s | %4s |  %5s | %5s |",
                             jugador, fase, campos[0], campos[1]));

        }

        System.out.println("+" + lineas + "+");

    }


    // muestra cantidad de puntos obtenidos por jugador
    public static void TotalesJugador(Map <String, Integer> puntosJugador,
                                      TreeMap <String, String> jugadorFasePuntos) {

        count = 0;
        puntos = 0;
        header = true;

        System.out.println();
        lineas = "--------------------------";
        titulo = "|   < TOTALES JUGADOR >    |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String player : puntosJugador.keySet()) {

            if (header) {
                System.out.println("| Jugador         | Puntos |");
                System.out.println("|" + lineas + "|");
                header = false;
            }

            puntos = puntosJugador.get(player);

            System.out.println(String.format("| %-15s | %6d |", player, puntos));

            if (puntosJugador.get(player) > count) {
                count = puntosJugador.get(player);
                ganador = player;
            }

        }

        System.out.println("+" + lineas + "+");

    }


    // muestra el jugador ganador de la competencia
    public static void Ganador() {

        System.out.println();
        lineas = "---------------------";
        titulo = "|   <<< GANADOR >>>   |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");
        System.out.println(String.format("|       %-10s    |", ganador));
        System.out.println("+" + lineas + "+");
        System.out.println("\n");

    }

}


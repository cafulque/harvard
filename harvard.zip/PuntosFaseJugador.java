//
/*
    unused class
*/

package cafu.prode;

public class PuntosFaseJugador {

    // declaraciones
    private int fase;
    private String jugador;
    private Integer puntos;
    private int bonus;

    // constructor
    public PuntosFaseJugador(int fase, String jugador, Integer puntos, int bonus) {
        super();
        this.fase = fase;
        this.jugador = jugador;
        this.puntos = puntos;
        this.bonus = bonus;
    }

    // getters & setters
    public int getFase() {
        return this.fase;
    }
    
    public void setFase(int fase) {
        this.fase = fase;
    }
    
    public String getJugador() {
        return this.jugador;
    }
    
    public void setJugador(String jugador) {
        this.jugador = jugador;
    }
    
    public Integer getPuntos() {
        return this.puntos;
    }

    public void setPuntos(Integer puntos) {
        this.puntos = puntos;
    }

    public int getBonus() {
        return this.bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

}

